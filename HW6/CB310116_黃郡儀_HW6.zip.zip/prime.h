#ifndef ISPRIME_H
#define ISPRIME_H

int IsPrime(int num);

#endif
