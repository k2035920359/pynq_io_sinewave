struct Pokemon
{
    char Name[100];
    int Lv;
    int Hp;
    //int p;
    
};
 
void InputData(struct Pokemon *);
void ShowInfo(struct Pokemon);
